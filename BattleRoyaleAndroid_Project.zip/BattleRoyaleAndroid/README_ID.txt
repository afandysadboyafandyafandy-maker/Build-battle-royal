BATTLE ROYALE MINI — PROYEK ANDROID WEBVIEW
===========================================

Isi:
- app/src/main/assets/index.html : game HTML, CSS, JavaScript
- MainActivity.java              : membuka game di Android WebView
- AndroidManifest.xml            : pengaturan aplikasi
- Gradle files                   : konfigurasi proyek

CARA MEMBUAT APK (PC/LAPTOP — Android Studio)
1. Pasang Android Studio dari situs resmi Android Developers.
2. Ekstrak ZIP ini ke folder di komputer.
3. Android Studio > Open > pilih folder BattleRoyaleAndroid.
4. Tunggu Gradle Sync selesai. Jika diminta, gunakan JDK 17 dan pasang Android SDK Platform 35.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Setelah selesai, klik "locate" pada notifikasi build. APK biasanya ada di:
   app/build/outputs/apk/debug/app-debug.apk
7. Pindahkan APK ke HP Android, buka file APK, lalu izinkan instalasi dari sumber tersebut jika Android meminta.
   Instal hanya APK yang kamu bangun sendiri dan percaya.

CATATAN
- Proyek ini adalah game 2D mini offline dengan bot, bukan Free Fire asli.
- Proyek ini bukan multiplayer online.
- File APK tidak disertakan karena APK harus dikompilasi dengan Android SDK/Gradle.
- Jika Android Studio menawarkan pembaruan plugin/Gradle otomatis, sebaiknya selesaikan sinkronisasi dan periksa pesan error.
