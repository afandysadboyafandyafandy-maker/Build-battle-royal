plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.battleroyale"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.battleroyale"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
